#include<stdint.h>

void playNote(uint16_t wavelength, uint16_t duration){

}
